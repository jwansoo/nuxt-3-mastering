<template>
  <h2>Lesson</h2>
  <p>This is lesson</p>
</template>

<script setup></script>

<style lang="scss" scoped></style>
